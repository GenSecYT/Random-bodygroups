-- File: lua/autorun/client/cl_gensec_npc_randomizer.lua

CreateClientConVar("gensec_model_list", "", true, true)

hook.Add("PopulateToolMenu", "GenSec_AddModelRandomizerPanel", function()
    spawnmenu.AddToolMenuOption("Options", "GenSec's", "NPC_Model_Randomizer", "NPC Model Randomizer", "", "", function(panel)
        panel:ClearControls()
        panel:Help("Enter model paths. Use checkboxes to enable/disable. Click 'Add model' to insert more.")

        local modelEntries = {}

        -- Scrollable area
        local scrollPanel = vgui.Create("DScrollPanel", panel)
        scrollPanel:SetTall(300)
        panel:AddItem(scrollPanel)

        -- Container inside scroll
        local entryContainer = vgui.Create("DPanel", scrollPanel)
        entryContainer:Dock(TOP)
        entryContainer:SetTall(0)
        entryContainer:SetPaintBackground(false)

        local function UpdateConVar()
            local models = {}
            for _, entry in ipairs(modelEntries) do
                if IsValid(entry.checkbox) and entry.checkbox:GetChecked() then
                    local t = entry.text:GetText():Trim()
                    if t ~= "" then table.insert(models, t) end
                end
            end
            RunConsoleCommand("gensec_model_list", table.concat(models, ","))
        end

        local function AddModelEntry(defaultText, isChecked)
            local row = vgui.Create("DPanel", entryContainer)
            row:SetTall(24)
            row:Dock(TOP)
            row:DockMargin(0, 0, 0, 4)
            row:SetPaintBackground(false)

            local checkbox = vgui.Create("DCheckBox", row)
            checkbox:Dock(LEFT)
            checkbox:SetWide(20)
            checkbox:SetChecked(isChecked or true)
            checkbox.OnChange = UpdateConVar

            local textEntry = vgui.Create("DTextEntry", row)
            textEntry:Dock(FILL)
            textEntry:SetText(defaultText or "")
            textEntry.OnChange = function()
                UpdateConVar()
            end

            local delButton = vgui.Create("DButton", row)
            delButton:Dock(RIGHT)
            delButton:SetWide(30)
            delButton:SetText("✖")
            delButton:SetTextColor(Color(200, 50, 50))
            delButton.DoClick = function()
                for i, v in ipairs(modelEntries) do
                    if v.panel == row then
                        table.remove(modelEntries, i)
                        break
                    end
                end
                row:Remove()
                UpdateConVar()
            end

            local entry = {
                panel = row,
                checkbox = checkbox,
                text = textEntry,
                del = delButton
            }

            table.insert(modelEntries, entry)

            -- Adjust container height
            entryContainer:SetTall(#modelEntries * 28)
        end

        local addButton = vgui.Create("DButton")
        addButton:SetText("Add model")
        addButton.DoClick = function()
            AddModelEntry("", true)
        end
        panel:AddItem(addButton)

        -- Load from convar
        local existing = GetConVar("gensec_model_list"):GetString()
        if existing ~= "" then
            for _, mdl in ipairs(string.Split(existing, ",")) do
                AddModelEntry(mdl, true)
            end
        end

        -- Resize entry container width to scroll width
        scrollPanel.PerformLayout = function(sp)
            entryContainer:SetWide(sp:GetWide())
        end
    end)
end)
