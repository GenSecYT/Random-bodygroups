-- File: lua/autorun/sh_gensec_npc_randomizer.lua

-- Split string by comma
local function SplitModelList(str)
    local t = {}
    for model in string.gmatch(str or "", "[^,]+") do
        t[#t + 1] = string.Trim(string.lower(model))
    end
    return t
end

-- Randomize bodygroups
local function RandomizeBodygroups(ent)
    if not IsValid(ent) or not ent:GetBodyGroups() then return end

    for _, bg in pairs(ent:GetBodyGroups()) do
        if bg.num > 1 then
            ent:SetBodygroup(bg.id, math.random(0, bg.num - 1))
        end
    end
end

-- Randomize skin
local function RandomizeSkin(ent)
    if not IsValid(ent) then return end
    local skinCount = ent:SkinCount() or 1
    if skinCount > 1 then
        ent:SetSkin(math.random(0, skinCount - 1))
    end
end

-- Hook for NPC spawn
hook.Add("OnEntityCreated", "GenSec_NPC_Model_Randomizer", function(ent)
    timer.Simple(0, function()
        if not IsValid(ent) or not ent:IsNPC() then return end
        local model = string.lower(ent:GetModel() or "")

        local cv = GetConVar("gensec_model_list")
        if not cv then return end
        local listStr = cv:GetString()
        if listStr == "" then return end

        local models = SplitModelList(listStr)
        for _, m in ipairs(models) do
            if model == m then
                RandomizeSkin(ent)
                RandomizeBodygroups(ent)
                break
            end
        end
    end)
end)
