-- File: lua/autorun/client/cl_gensec_npc_randomizer.lua

CreateClientConVar("gensec_model_list", "", true, true)

hook.Add("PopulateToolMenu", "GenSec_AddModelRandomizerPanel", function()
    spawnmenu.AddToolMenuOption("Options", "GenSec's", "NPC_Model_Randomizer", "NPC Model Randomizer", "", "", function(panel)
        panel:ClearControls()
        panel:Help("Enter model paths. Use checkboxes to enable/disable. Click 'Add model' to insert more.")

        local modelEntries = {}

        -- Scrollable area
        local scrollPanel = vgui.Create("DScrollPanel", panel)
        scrollPanel:SetTall(300)
        panel:AddItem(scrollPanel)

        -- Container inside scroll
        local entryContainer = vgui.Create("DPanel", scrollPanel)
        entryContainer:Dock(TOP)
        entryContainer:SetTall(0)
        entryContainer:SetPaintBackground(false)

        local function UpdateConVar()
            local models = {}
            for _, entry in ipairs(modelEntries) do
                if IsValid(entry.checkbox) and entry.checkbox:GetChecked() then
                    local model = entry.text:GetText():Trim()
                    local mode = entry.mode or "B&S"
                    if model ~= "" then
                        table.insert(models, model .. "|" .. mode)
                    end
                end
            end
            RunConsoleCommand("gensec_model_list", table.concat(models, ","))
        end

        local function CycleMode(current)
            if current == "B" then return "S" elseif current == "S" then return "B&S" else return "B" end
        end

        local function AddModelEntry(defaultText, isChecked, mode)
            local row = vgui.Create("DPanel", entryContainer)
            row:SetTall(24)
            row:Dock(TOP)
            row:DockMargin(0, 0, 0, 4)
            row:SetPaintBackground(false)

            local entry = {
                panel = row,
                checkbox = nil,
                text = nil,
                del = nil,
                modeBtn = nil,
                mode = mode or "B&S"
            }

            local checkbox = vgui.Create("DCheckBox", row)
            checkbox:Dock(LEFT)
            checkbox:SetWide(20)
            checkbox:SetChecked(isChecked or true)
            checkbox.OnChange = UpdateConVar
            entry.checkbox = checkbox

            local textEntry = vgui.Create("DTextEntry", row)
            textEntry:Dock(FILL)
            textEntry:SetText(defaultText or "")
            textEntry.OnChange = UpdateConVar
            entry.text = textEntry

            local modeButton = vgui.Create("DButton", row)
            modeButton:Dock(RIGHT)
            modeButton:SetWide(35)
            modeButton:SetText(entry.mode)
            modeButton.DoClick = function()
                entry.mode = CycleMode(entry.mode)
                modeButton:SetText(entry.mode)
                UpdateConVar()
            end
            entry.modeBtn = modeButton

            local delButton = vgui.Create("DButton", row)
            delButton:Dock(RIGHT)
            delButton:SetWide(30)
            delButton:SetText("✖")
            delButton:SetTextColor(Color(200, 50, 50))
            delButton.DoClick = function()
                for i, v in ipairs(modelEntries) do
                    if v.panel == row then
                        table.remove(modelEntries, i)
                        break
                    end
                end
                row:Remove()
                UpdateConVar()
            end
            entry.del = delButton

            table.insert(modelEntries, entry)
            entryContainer:SetTall(#modelEntries * 28)
        end

        local addButton = vgui.Create("DButton")
        addButton:SetText("Add model")
        addButton.DoClick = function()
            AddModelEntry("", true, "B&S")
        end
        panel:AddItem(addButton)

        -- Load from convar
        local existing = GetConVar("gensec_model_list"):GetString()
        if existing ~= "" then
            for _, mdlpair in ipairs(string.Split(existing, ",")) do
                local parts = string.Split(mdlpair, "|")
                local mdl = parts[1] or ""
                local mode = parts[2] or "B&S"
                AddModelEntry(mdl, true, mode)
            end
        end

        scrollPanel.PerformLayout = function(sp)
            entryContainer:SetWide(sp:GetWide())
        end
    end)
end)
