-- File: lua/autorun/sh_gensec_npc_randomizer.lua

local function SplitModelList(str)
    local t = {}
    for pair in string.gmatch(str or "", "[^,]+") do
        local mdl, mode = string.match(pair, "([^|]+)|?(.*)")
        mdl = string.Trim(string.lower(mdl or ""))
        mode = mode ~= "" and mode or "B&S"
        t[#t + 1] = {model = mdl, mode = mode}
    end
    return t
end

local function RandomizeBodygroups(ent)
    if not IsValid(ent) or not ent:GetBodyGroups() then return end
    for _, bg in pairs(ent:GetBodyGroups()) do
        if bg.num > 1 then
            ent:SetBodygroup(bg.id, math.random(0, bg.num - 1))
        end
    end
end

local function RandomizeSkin(ent)
    if not IsValid(ent) then return end
    local skinCount = ent:SkinCount() or 1
    if skinCount > 1 then
        ent:SetSkin(math.random(0, skinCount - 1))
    end
end

hook.Add("OnEntityCreated", "GenSec_NPC_Model_Randomizer", function(ent)
    timer.Simple(0, function()
        if not IsValid(ent) or not ent:IsNPC() then return end

        local model = string.lower(ent:GetModel() or "")
        local cv = GetConVar("gensec_model_list")
        if not cv then return end

        local listStr = cv:GetString()
        if listStr == "" then return end

        local models = SplitModelList(listStr)
        for _, entry in ipairs(models) do
            if model == entry.model then
                if entry.mode == "B" or entry.mode == "B&S" then
                    RandomizeBodygroups(ent)
                end
                if entry.mode == "S" or entry.mode == "B&S" then
                    RandomizeSkin(ent)
                end
                break
            end
        end
    end)
end)
